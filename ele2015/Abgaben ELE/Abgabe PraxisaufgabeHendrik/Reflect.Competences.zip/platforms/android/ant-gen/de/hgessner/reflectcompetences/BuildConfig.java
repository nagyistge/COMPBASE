/** Automatically generated file. DO NOT MODIFY */
package de.hgessner.reflectcompetences;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}